package com.ur.style.components;

public class URLoadingBar {
}
