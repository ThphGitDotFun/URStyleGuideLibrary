package com.ur.style;

public class URToolbarLogo {

    public URToolbarLogo() {

    }

    //Maximum logo width in px
    public int maximumWidth = 89;


    //Maximum logo height in px
    public int getMaximumHeight = 30;

}
