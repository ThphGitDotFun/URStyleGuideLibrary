package com.ur.style.components;

import com.ur.style.URBorder;
import com.ur.style.URColorPalette;
import com.ur.style.URLayout;
import com.ur.style.URTypegraphy;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;


public class URToggles {

    private URBorder border = new URBorder();
    private URColorPalette urColorPalette = new URColorPalette();
    private URLayout urLayout = new URLayout();
    private URTypegraphy typegraphy = new URTypegraphy();

    public URToggles() {
    }

    public JToggleButton getLargeToggleEnabled(JToggleButton largeToggleEnabled, String toggleText, int layoutColumWidth) {

        Border myToggleBorder = BorderFactory.createLineBorder(urColorPalette.UR_BLUE,border.BORDER_NORMAL);
        Font font = new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE);
        int columWidth = layoutColumWidth;


        if(toggleText.equals(null)||toggleText.equals(""))

            {
                largeToggleEnabled.setText("Enable");
            }
        else if(columWidth == 0) {

            columWidth = urLayout.installationColumWidth;
        }

        else

            {
                largeToggleEnabled.setPreferredSize(new Dimension(layoutColumWidth, border.HEIGHT_VERY_LARGE));
                largeToggleEnabled.setMaximumSize(largeToggleEnabled.getPreferredSize());
                largeToggleEnabled.setBorder(myToggleBorder);
                largeToggleEnabled.setFocusable(false);
                largeToggleEnabled.setFont(new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE));
                largeToggleEnabled.setForeground(urColorPalette.BLACK);
                largeToggleEnabled.setBackground(urColorPalette.WHITE);
                largeToggleEnabled.setEnabled(true);

            }


        return largeToggleEnabled;
    }

    public JToggleButton getLargeToggleDisabled(JToggleButton largeToggleDisabled, String toggleText, int layoutColumWidth) {
        Border myToggleBorder = BorderFactory.createLineBorder(urColorPalette.GRAY_5,border.BORDER_NORMAL);
        Font font = new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE);
        int columWidth = layoutColumWidth;


        if(toggleText.equals(null)||toggleText.equals(""))

        {
            largeToggleDisabled.setText("Disable");
        }
        else if(columWidth == 0) {

            columWidth = urLayout.installationColumWidth;
        }

        else

        {
            largeToggleDisabled.setPreferredSize(new Dimension(layoutColumWidth, border.HEIGHT_VERY_LARGE));
            largeToggleDisabled.setMaximumSize(largeToggleDisabled.getPreferredSize());
            largeToggleDisabled.setBorder(myToggleBorder);
            largeToggleDisabled.setFocusable(false);
            largeToggleDisabled.setFont(new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE));
            largeToggleDisabled.setForeground(urColorPalette.GRAY_5);
            largeToggleDisabled.setBackground(urColorPalette.WHITE);
            largeToggleDisabled.setEnabled(false);

        }


        return largeToggleDisabled;
    }

    public JToggleButton getSmallToggleDeselected(JToggleButton smallToggleDeselected, String toggleText, int layoutColumWidth) {
        Border myToggleBorder = BorderFactory.createLineBorder(urColorPalette.UR_BLUE,border.BORDER_NORMAL);
        Font font = new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE);
        int columWidth = layoutColumWidth;
        if(toggleText.equals(null)||toggleText.equals(""))

        {
            smallToggleDeselected.setText("Selected");
        }
        else if(columWidth == 0) {

            columWidth = urLayout.installationColumWidth;
        }

        else

        {
            smallToggleDeselected.setPreferredSize(new Dimension(layoutColumWidth, border.HEIGHT_MEDIUM));
            smallToggleDeselected.setMaximumSize(smallToggleDeselected.getPreferredSize());
            smallToggleDeselected.setBorder(myToggleBorder);
            smallToggleDeselected.setFocusable(false);
            smallToggleDeselected.setFont(new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE));
            smallToggleDeselected.setForeground(urColorPalette.BLACK);
            smallToggleDeselected.setBackground(urColorPalette.WHITE);
            smallToggleDeselected.setEnabled(false);

        }

        return smallToggleDeselected;
    }

    public JToggleButton getSmallToggleSelected(JToggleButton smallToggleSelected, String toggleText, int layoutColumWidth) {
        Border myToggleBorder = BorderFactory.createLineBorder(urColorPalette.UR_BLUE,border.BORDER_NORMAL);
        Font font = new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE);
        int columWidth = layoutColumWidth;
        if(toggleText.equals(null)||toggleText.equals(""))

        {
            smallToggleSelected.setText("Selected");
        }
        else if(columWidth == 0) {

            columWidth = urLayout.installationColumWidth;
        }

        else

        {
            smallToggleSelected.setPreferredSize(new Dimension(layoutColumWidth, border.HEIGHT_MEDIUM));
            smallToggleSelected.setMaximumSize(smallToggleSelected.getPreferredSize());
            smallToggleSelected.setBorder(myToggleBorder);
            smallToggleSelected.setFocusable(false);
            smallToggleSelected.setFont(new Font(typegraphy.FontFamilie_DejaVu,typegraphy.Bold,typegraphy.FONT_VERY_LARGE));
            smallToggleSelected.setForeground(urColorPalette.BLACK);
            smallToggleSelected.setBackground(urColorPalette.WHITE);
            smallToggleSelected.setEnabled(false);

        }
        return smallToggleSelected;
    }

}
