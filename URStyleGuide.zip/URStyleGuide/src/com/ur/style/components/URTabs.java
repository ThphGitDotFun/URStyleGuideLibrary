package com.ur.style.components;

public class URTabs {
}
